/**
 * Created by yqf on 2017/10/30.
 */


//创建群聊第一个页面

import { extendObservable, action, computed, toJS, observable } from 'mobx';
import { Alert, NativeModules, ListView } from 'react-native';


export default  class GroupCreate{

    @observable text = '';


}
