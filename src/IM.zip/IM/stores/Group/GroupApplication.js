/**
 * Created by yqf on 2017/11/1.
 */
//申请加入群第一个页面

import { extendObservable, action, computed, toJS, observable } from 'mobx';
import { Alert, NativeModules, ListView } from 'react-native';

export default  class GroupApplication{

    @observable text = '';

}
