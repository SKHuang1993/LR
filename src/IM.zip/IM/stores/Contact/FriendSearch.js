/**
 * Created by yqf on 2017/11/1.
 */


import { extendObservable, action, computed, toJS, observable } from 'mobx';
import { Alert, NativeModules, ListView } from 'react-native';


import {Chat}  from '../../utils/chat';
import {IM}  from '../../utils/data-access/im';



export default  class FriendSearch{


    @observable title;//标题

    @observable type;//类型 （联系人中的好友，群组， 搜索好友）

    @observable isLoading = false;判断是否要显示加载

    @observable isEmpty = false;//判断是否为空页面

    @observable Users = [];//数组

    @observable keyWord = null;//搜索关键词

    @computed get getDataSource(){

       console.log('FriendSearch--')

        ds = new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !==r2});
        return ds.cloneWithRows(this.Users.slice());

    }


}
