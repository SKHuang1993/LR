/**
 * Created by yqf on 2017/11/1.
 */




import {Component} from 'react';
import React, { PropTypes } from 'react';
import RCTDeviceEventEmitter from 'RCTDeviceEventEmitter'

import {

    StyleSheet,
    Image,
    Text,
    View,
    TextInput

} from 'react-native';

import {Chat} from './utils/chat';
import {IM} from './utils/data-access/im';

import PictureTemplate from'./pages/Poster/PictureTemplate';
import VideoList from'../IM/pages/Professional/VideoList';


export  default  class IMAppTest extends Component{


    constructor(props){
        super(props);

        this.state={
            Array:['申请加群','添加好友','创建群聊','新增成员','移除成员']
        }
    }

   async Addtag(){


        var UserTags = [];

        var usertag={
            Action:1,
            Name:'mobile',
            UserTagMembers:[
                {
                    Action:1,
                    IMNr:'1250',
                },

                {
                    Action:1,
                    IMNr:'1111',
                },

                {
                    Action:1,
                    IMNr:'1186',
                },
            ]


        };

        UserTags.push(usertag);

        var Param = {

            IMNr:'1923',
            UserTags:UserTags

        }


     var result = await  IM.getIMSystemUserTagMemberCD(Param);



    }


    //选择
    _selectTemplate = ()=>{

       this.props.navigator.push({
           component:PictureTemplate
       })



    }




    //图片海报
    photoPoster = ()=>{



    }


    //视频海报
    videoPoster = ()=>{


    }

    _ToVideo = ()=>{


        this.props.navigator.push({
            component:VideoList
        })
    }

    render(){


        return(


            <View style={{marginTop:50}}>


                {

                    this._renderBtnWithTitle('生产图片海报',()=>{

                        this.photoPoster();

                    })

                }


                {this._renderBtnWithTitle('生产视频海报',()=>{

                    this.videoPoster();

                })}

                {this._renderBtnWithTitle('选择图片模版',()=>{

                    this._selectTemplate();

                })}


                {this._renderBtnWithTitle('选择图片模版',()=>{

                    this._selectTemplate();

                })}


                {this._renderBtnWithTitle('培训学院',()=>{

                    this._ToVideo();

                })}

            </View>


        )

    }

    _renderBtnWithTitle(title,onPress){

        return(
          <Text onPress={onPress} style={{margin:10}}>{title}</Text>
        );
    }

}