/**
 * Created by yqf on 2017/9/16.
 */

import Colors from './Colors'
import Fonts from './Fonts'
import Metrics from './Metrics'
import ApplicationStyles from './ApplicationStyles'
import Images from './Images';


export  default {
    Colors,
    Fonts,
    Metrics,
    ApplicationStyles,
    Images,

}