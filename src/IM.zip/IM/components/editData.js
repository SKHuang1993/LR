/**
 * Created by yqf on 2017/11/5.
 */



import React, { Component } from 'react';

import {

    StyleSheet,
    View,
    Image,
    Text,
    ListView,
    TextInput,
    TouchableOpacity,
    Dimensions,
    // Navigator,

} from 'react-native';



import YQFNavBar from './yqfNavBar';

let window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,
}



export  default  class EditData extends Component
{

    constructor(props)
    {
        super(props);
        this.state={

            text:this.props.value,
        };
    }

    _confirm()
    {

        let text = this.state.text;

        var str = text.replace(/\s+/g,"");

        if(text.length == 0)
        {

            if(this.props.getDetail){
                this.props.getDetail(this.props.value);

            }
            this.props.navigator.pop();
        }

        else
        {


            //提出提示框，将输入的文字传回去
            if(this.props.getDetail){
                this.props.getDetail(text);
            }

            this.props.navigator.pop();


        }



    }



    _renderNav(){

        return(
            <YQFNavBar
                navigator={this.props.navigator}
                title={this.props.title}
                leftIcon={'0xe183'}
                rightText={'提交'}

                              onLeftClick={()=>{


            this.props.navigator.pop();

                                  }}
                              onRightClick={()=>{this._confirm()}}
            />

        )


    }

    _renderTextInput(){

        var str;
        if(this.props.placeholder){

             str = this.props.placeholder.replace(/\s+/g,"");
        }else {
            str=null;
        }


        return(
            <View style={{backgroundColor:'white',}}>

                <TextInput

                    underlineColorAndroid={'transparent'}
                    multiline={true}
                    value={this.state.text}
                    placeholder={str}
                    returnKeyType={'send'}
                    onChangeText={(text)=>{
                              this.setState({

                   text:text,

               })


                        }}



                    style={{height:100,backgroundColor:'white',fontSize:15,margin:5}}>


                </TextInput>



            </View>
        )

    }




    render()
    {
        return(


            <View style={{backgroundColor:'rgb(235,235,235)',flex:1}}>

                {this._renderNav()}

                {this._renderTextInput()}


            </View>




        )
    }




}





