/**
 * Created by yqf on 2017/10/31.
 */


//用户资料页面

/**
 * Peer -》账号(必填)
 * User->用户资料。如果有传，则直接用。没有的话，则需要去获取
 * isContact->是否为好友。最好是传过来。如果没有传，则需要去通讯录中判断
 *Wording ->有传则代表验证页面
 *
 *
 *
 * */



import { observer } from 'mobx-react/native';
import {observable, autorun,computed,action} from 'mobx'
import {Component} from 'react';
import React, { PropTypes } from 'react';
import RCTDeviceEventEmitter from 'RCTDeviceEventEmitter';
import YQFNavBar from '../../components/yqfNavBar';
import Icon from '../../components/icon';

import Button from '../../components/Button';

import LoadingView from '../../components/LoadingView';
import LeftTitleCenterTitle from '../../components/LeftTitleCenterTitle';
import Colors from '../../Themes/Colors';

import {IM} from '../../utils/data-access/im';
import {Chat} from '../../utils/chat';

import chatUserInfo from '../../stores/Chat/ChatUserInfo';
import Enumerable from 'linq';

import FriendApplication from '../Contact/FriendApplication';
import {ServingClient,RestAPI} from '../../utils/yqfws';
import ChatRoom from '../../pages/Chat/ChatRoom';
import ServiceLog from './serviceLog';
import ChatTag from './ChatTag';

//xg
import MyWebView from '../../components/webview1';
import ImageViewer from 'react-native-image-zoom-viewer';


let window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,

}

let margin=10;
let imageW = 50;
let iconW = 70;



import {
    TouchableOpacity,
    StyleSheet,
    Image,
    ListView,
    Text,
    View,
    RefreshControl,
    Dimensions,
    ScrollView,
    InteractionManager,
    NativeModules,
    Platform,
    Modal


} from 'react-native';

@observer
export  default class ChatUserInfo extends Component{

    constructor(props){
        super(props);

        this.store = new chatUserInfo();

        this.store.Peer = this.props.Peer;

        this.store.LoginIMNr = Chat.getLoginInfo().User.IMNr;

        this.store.isContact = this.props.isContact ? this.props.isContact : null;


        this.state={
            imageViewer: false

        }

        // this.store.Wording = this.props.Wording ? this.props.Wording : null;



    }

    componentDidMount(){

        this.listener = RCTDeviceEventEmitter.addListener('KickOff',()=>{

            this.props.navigator.popToTop();

        });

        this._fetchData();
    }


    componentWillUnmount(){

        this.listener &&this.listener.remove();


    }

   async _fetchData(){


       var title;

        //如果没有传用户资料过来
        if(!this.store.User){

            var Param = {UserNrs: [this.store.Peer]};
            var result = await IM.getUserOrGroups(Param);

            // console.dir(result);
            if(result){
                this.store.User = result.Users[0];
                this.store.isLoading = false;
                // console.log('当前的用户资料')
                // console.dir(this.store.User);

            }

        }


        // console.log('当前的用户资料')
        // console.dir(this.store.User);

        //如果没有传是否为联系人，需要去获取
       if(this.store.isContact == null){

            var result = await IM.getContacts({Owner:Chat.getLoginInfo().User.IMNr});
            // console.log('result---服务器的数据')
            // console.dir(result);
            var Users = result.Users;

           var index = Users.findIndex((object)=>{
               return object.User.IMNr ==this.store.Peer;
           })

           if(index == -1){

               this.store.isContact = false;
               title = '添加到通讯录';
               // console.log('找不到');
           }

           else {

               this.store.isContact = true;
               title = '发消息';
               // console.log('找到了，是好友');
               // alert(index);
           }

       }
       else {
           title = '发消息';
       }

       this.store.title = title;


//图片地址（后期需要修改成调用老接口获取）
       var Param = {

           UserCode: this.store.User.UserCode,
           ArticleAccessAuthorityIDs: '1',
           PageCount:1,
           PageSize:4,
           ArticleCategoryID:['6'],
       };

       RestAPI.invoke('Knowledge.ArticleListGetForMobile',Param,(success)=>{

           // console.log('Knowledge.ArticleListGetForMobile --请求返回结果')
           // console.dir(success);

           var Images=[];

           for(var i=0;i<success.Result.ArticleList.length;i++){

               var article = success.Result.ArticleList[i];

               if(article.Images){

                   Images = Images.concat(article.Images);
               }

           }


           this.store.Images =Images;


       });



       var tempTags =[];
       //请求标签
       var resultTag =await IM.getIMSystemUserTagByIMNr({
           IMNr:Chat.userInfo.User.IMNr
       });

       if( resultTag.IMUserTags && resultTag.IMUserTags.length>0){


         var totalTags= resultTag.IMUserTags;


           // console.log('getIMSystemUserTagByIMNr');
           // console.dir(totalTags);

           var Peer = this.store.Peer;

           //在这里面去寻找对应的那人

           for(var i=0;i<totalTags.length;i++){

               var tag = totalTags[i];

               for(var j=0;j<tag.Members.length;j++){

                   var member = tag.Members[j];

                   if(member.IMNr == Peer){
                       tempTags.push(tag);
                       break;
                   }

               }

           }

           // console.log('tempTags');
           // console.dir(tempTags);


           var str = this._getTagStr(tempTags);

       //    alert(str);

           //this.store.Tag = tempStr;


       }




   }


   _getTagStr = (Tags)=>{

       var str='';
       Enumerable.from(Tags).where((o)=>{

           str+=o.Name+','
       })

       return str;

   }


    _ToChatRoom=()=>{

       Chat.createConversation(this.props.navigator,this.store.User.IMNr,this.store.User.Name,'C2C');
    }

    _ToCallPhone=()=>{

       if(this.store.User.CustomerService.WorkPhone){

           NativeModules.MyNativeModule.callPhone(this.store.User.CustomerService.WorkPhone);
       }

    }

    _ToWoquguoHome = ()=>{


        // alert('_ToWoquguoHome，跳到我去过个人主页');

        if(this.store.User.RoleType == 'INCU')
        {

            var webUrl='http://3g.yiqifei.com/i/'+this.store.User.UserCode;
            InteractionManager.runAfterInteractions(() => {
                this.props.navigator.push({
                    name:'MyWebView',
                    component:MyWebView,
                    passProps:{
                        webUrl:webUrl,
                    },

                })
            })
        }

        else
        {

            InteractionManager.runAfterInteractions(() => {
                this.props.navigator.push({
                    name:'ArticleAuthor',
                    component:ArticleAuthor,
                    passProps:{
                        articleItem:this.props.articleItem,
                        loginUserCode:this.state.UserCode,
                        //fromType:this.state.isSelf ? 'selfAuthor':'otherArticle',
                        fromType:'selfAuthor',
                        isSelef:false,



                    }
                })
            })
        }




    }

    _ToServiceLog =()=>{


        this.props.navigator.push({

            component:ServiceLog,
            passProps:{

            }
        })


    }

    _ToFriendApplication = ()=>{

        //console.warn('点击跳到好友申请页面,传递ID过去');
        //跳到好友验证页面。回调回来的时候需要将状态处理回来
        this.props.navigator.push({

            component:FriendApplication,
            passProps:{
                User:this.store.User
            }
        })

    }



    _ToChatTag = ()=>{

        this.props.navigator.push({

            component:ChatTag,
            passProps:{

                tag:this.store.tag,
                getTag:((tagString)=>{

                    // console.log('设置标签后的回调');
                    // console.dir(tagString);
                    this.store.tag = tagString;

                })

            }

        })

    }


    toggle = () => {
        this.setState({
            imageViewer: !this.state.imageViewer
        })
    }


    //导航栏
    _renderNav(){

        return(
            <YQFNavBar title={'详细资料'} leftIcon={'0xe183'} onLeftClick={()=>{this.props.navigator.pop() }} />
        )
    }


    //头部
    _renderAvatar(){

//Todo
       // console.log('可以获取到Rank和性别，后期加上');
       var Gender = this.store.User.Gender == 'Female' ? '女' : '男';

        return(
            <View
                style={[{padding:margin,backgroundColor:'white',marginTop:margin},styles.row]}>


                <TouchableOpacity onPress={()=>{this.toggle()}}>

                <Image
                    style={{width:iconW,height:iconW,resizeMode:'cover',borderRadius:5}}
                    source={{uri:Chat.getFaceUrlPath(this.store.User.FaceUrlPath)}}>

                </Image>
                </TouchableOpacity>



                    <View style={{flexDirection:'row',justifyContent:'space-around'}}>

                        <View style={{marginLeft:margin,justifyContent:'space-around',}}>

                            <View style={{flexDirection:'row',alignItems:'center'}}>

                                <Text style={{color:Colors.colors.Chat_Color153,fontSize:13,marginTop:0}}>{'账号:' + this.store.User.IMNr}</Text>

                                <Icon style={{marginLeft:5}} size={14} color={Gender=='女' ?'red' : 'blue'} icon={'0xe15c'}/>

                            </View>


                        <Text
                            style={{color:Colors.colors.Chat_Color153,fontSize:13,}}>{'昵称:' + this.store.User.Name}</Text>

                            {
                                this.store.User.Rank ?

                                    <Text
                                        style={{color:Colors.colors.Chat_Color153,fontSize:13,}}>{'Rank:' + this.store.User.Rank}</Text>
                                    :
                                    null
                            }


                        </View>





                    </View>






            </View>
        )

    }

    //申请说明
    _renderWording(){

        // if(this.store.Wording && this.store.Wording.length>0){
        //
        //     return(
        //         <View style={{padding:20,backgroundColor:Colors.colors.Chat_Color240}}>
        //
        //             <Text style={{color:Colors.colors.Chat_Color102}}>{'申请说明:'+this.store.Wording}</Text>
        //
        //         </View>
        //     )
        // }

        return null;

    }

    //电话
    _renderPhone(){

        if(this.store.User && this.store.User.CustomerService && this.store.User.CustomerService.WorkPhone){

            return(

                <LeftTitleCenterTitle style={{marginTop:margin}} leftTitle={'电话号码'}
                                         rightTitle={this.store.User.CustomerService.WorkPhone}
                                         rightTitleColor={Colors.colors.Chat_ThemeColor}
                                         isShowArrow={false}
                                         rightTitleStyle={{marginRight:20}}
                                         onPress={()=>{

                                             this._ToCallPhone();
                    }}/>
            )

        }
       return null;
    }

    //标签
    _renderTag(){


        //如果这个用户有标签，则直接拿出来，如果没有。则是空白，点击过去跳转

        return null;

/*
        return(

            <LeftTitleCenterTitle style={{marginTop:0}} leftTitle={'标签'}
                                     rightTitle={this.store.tag}
                                     isShowArrow={true}
                                     onPress={()=>{

                                        this._ToChatTag();
                    }}/>
            )
*/



    }

    //地区
    _renderAddress(){

        if(this.store.User && this.store.User.CustomerService && this.store.User.CustomerService.Address){

            return(
                <LeftTitleCenterTitle style={{marginTop:margin}} leftTitle={'地区'}
                                      rightTitle={this.store.User.CustomerService.Address}
                                      isShowArrow={false}
                                      onPress={()=>{

                    }}/>
                )

        }

        return null

    }

    //个性签名
    _renderIntro(){

        if(this.store.User && this.store.User.CustomerService && this.store.User.CustomerService.Intro){

            return(
                <LeftTitleCenterTitle style={{marginTop:0}} leftTitle={'个性签名'}
                                      rightTitle={this.store.User.CustomerService.Intro}
                                      isShowArrow={false}
                                      onPress={()=>{

                    }}/>

            )

        }

        return null


    }

    //个人相册
    _renderImage(){
        var Images = Enumerable.from(this.store.Images).takeFromLast(4).toArray();

if(Images && Images.length>0){

    return(

        <TouchableOpacity  onPress={()=>{


//员工账号(点击图片跳到对应的链接去)

                    this._ToWoquguoHome()




            }} style={{backgroundColor:'white',flexDirection:'row',alignItems:'center',marginTop:margin}}>


            <Text style={{color:'rgb(51,51,51)',fontSize:16,margin: 10,marginTop:35,marginLeft:20, marginBottom:35}}>{'个人相册'}</Text>

            <View style={{flexDirection:'row-reverse',alignItems:'center',}}>

                <View style={{flexDirection:'row',margin:15,backgroundColor:'white'}}>

                    {

                        Images.map((value,i)=>{

                            var path = 'http://img8.yiqifei.com'+value.Path;

                            return(

                                <Image style={{width:imageW,height:imageW,marginRight:10}}
                                       source={{uri:path}}>
                                </Image>


                            );

                        })





                    }






                </View>



            </View>

        </TouchableOpacity>


    );

}
return null;






    }

    //按钮组件
    _renderButton(){

        if(this.store.isContact == true){

            return(



                <View style={{margin:margin}}>


                    <View style={{margin:5}}>
                        <Button onPress={()=>{this._ToChatRoom()}}
                                borderRadius={5}
                                backgroundColor={Colors.colors.Chat_ThemeColor}
                                height={47}
                                titleFont={20}
                                title={'发消息'}
                                titleColor={'white'}></Button>
                    </View>


                    <View style={{margin:5}}>

                        {
                       this.store.User && this.store.User.CustomerService && this.store.User.CustomerService.WorkPhone ?

                           <Button onPress={()=>{this._ToCallPhone()}}
                                   borderRadius={5}
                                   backgroundColor={Colors.colors.Chat_ThemeColor} height={47}
                                   title={'打电话'}
                                   titleFont={20}
                                   titleColor={'white'}></Button>
                           :
                           null
                        }

                    </View>

                </View>


            )

        }
        else if(this.store.isContact == false){

            return(
                <View style={{margin:margin}}>


                    <Button onPress={()=>{this._ToFriendApplication()}} borderRadius={5} backgroundColor={Colors.colors.Chat_ThemeColor} height={39}
                            title={'添加到通讯录'}
                            titleColor={'white'}></Button>

                </View>
                )

        }



        return null



    }

    _renderService(){


       // console.warn('_renderService部分需要将读取网络服务记录的接口，下周做')

        return null;

/*
        return(

            <TouchableOpacity  onPress={()=>{


this._ToServiceLog();

            }} style={{backgroundColor:'white',flexDirection:'row',alignItems:'center',marginTop:margin}}>


                <Text style={{color:'rgb(51,51,51)',fontSize:13,margin: 10,marginTop:35,marginBottom:35}}>{'服务记录'}</Text>


                <View style={{flexDirection:'row-reverse',alignItems:'center',}}>

                    <View style={{margin:15,backgroundColor:'white'}}>

                        {

                            ['1','2','3'].map((value,i)=>{

                                return(

                                    <Text numberOfLines={1} style={{margin:5,color:'rgb(102,102,102)'}}>
                                        {'服务记录（等黄璡接口）'}
                                    </Text>

                                );

                            })





                        }






                    </View>



                </View>

            </TouchableOpacity>

        )
        */


    }

    _renderContent(){


        if(this.store.isLoading == true){

            return(

                <LoadingView backgroundColor={'rgb(230,230,230)'} title={'正在加载中...'}/>
            )

        }
        else {

            return(

                <ScrollView>

                    {this._renderAvatar()}
                    {this._renderWording()}
                    {this._renderPhone()}
                    {this._renderTag()}
                    {this._renderAddress()}
                    {this._renderIntro()}
                    {this._renderImage()}
                    {this._renderService()}
                    {this._renderButton()}


                </ScrollView>

            )
        }

    }

    render(){

        return(

            <View style={{flex:1,backgroundColor:'rgb(240,240,240)'}}>

                {this._renderNav()}

                {this._renderContent()}

            </View>

            )


    }

}


const styles = StyleSheet.create({




    row: {
      flexDirection:'row'
    },

});