/**
 * Created by yqf on 2017/11/1.
 */



import { observer } from 'mobx-react/native';

import {observable, autorun,computed,action} from 'mobx'
import {Component} from 'react';
import React, { PropTypes } from 'react';

import RCTDeviceEventEmitter from 'RCTDeviceEventEmitter'



import {
    TouchableOpacity,
    StyleSheet,
    Image,
    ListView,
    Text,
    View,
    RefreshControl,
    Dimensions,
    Alert

} from 'react-native';


import {IM} from '../../utils/data-access/im';
import {ServingClient,RestAPI} from '../../utils/yqfws';
import {Chat} from '../../utils/chat';
import Colors from '../../Themes/Colors';
import YQFNavHeaderView from '../../components/navHeaderView';
import friendSearch from '../../stores/Contact/FriendSearch';
import YQFEmptyView from '../../components/EmptyView';
import FriendApplication from './FriendApplication';
import ChatUserInfo from '../Chat/ChatUserInfo';
import Icon  from '../../components/icon'

const window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,
}

@observer
export default class FriendSearch extends Component{

    constructor(props){
        super(props);

        this.store = new friendSearch();
        this.store.type = this.props.type;

        if(this.store.type == 'INCU'){
            this.store.title = '搜索内部同事'
        } else if(this.store.type =='PictureTemplate'){
            this.store.title = '输入目的地/标签/关键词查找素材'
        }
        else {
            this.store.title = '输入联系人'
        }

    }


    _search(){



        //点击搜索的时候，将当前的数据清空，同时将Loading改为true
        this.store.Users = [];
        this.store.isLoading = true;

        var value = this.refs._nav.state.value;
        var type = this.store.type;
        this.store.keyWord = value;

        if(value.length<=0){

            Alert.alert('请'+this.store.title);
            return;
        }

        else {


            //搜索本地联系人
            if(type == 'Contact')
            {
                this._searchUserByLocal();
            }
            //搜索用户
            else if(type == 'Search_User')
            {
                this._searchUserByLink();
            }


            else if(type == 'INCU'){

                this._searchOrganization();
            }else if(type =='PictureTemplate'){


                this._searchPictureTemplate();
            }

            //搜索群聊
            else{


            }


        }


    }

    //搜索图片素材
    _searchPictureTemplate = async()=>{

        //暂时调用我去过的搜索游记接口
        var param ={

            StartDate:'2016-11-19T00:00:00',
            EndDate:'2030-01-10T00:00:00',
            FileTypeID:1,
            PageSize:1000,
            Condition:this.store.keyWord

        };

        var result = await  ServingClient.execute('Channel.MaterialLibraryByCondition',param);

        // console.log('搜索素材的结果 MaterialLibraryByCondition')
        // console.dir(result);

        if(result && result.MaterialLibraryList && result.MaterialLibraryList.length>0){


            this.store.isLoading = false;
            this.store.Users = result.MaterialLibraryList;
        }

        else {

            this.store.isLoading = false;
            this.store.isEmpty = true;
        }





    }

    //搜索内部同事
    async _searchOrganization(){


        var result =await IM.getUserIMNrBySubTypeCode();
        var UserLists = result.IMUserLists;//所有的内部同事

        var Users=[];
        //遍历联系人
        for(var i=0;i<UserLists.length;i++)
        {
            var User = UserLists[i];

            if(User.AliasName &&  User.AliasName.indexOf(this.store.keyWord)>-1)
            {
                Users.push(User);
            }
        }



        if(UserLists && Users && Users.length>0){


            this.store.isLoading = false;
            this.store.Users = Users;

        }

        else {

            this.store.isLoading = false;
            this.store.isEmpty = true;


        }



    }


    //本地搜索好友
    async  _searchUserByLocal(){

        var response = await Chat._GetContacts();

        var Users=[];//联系人
        var Groups =[];//群组

        //遍历联系人
        for(var i=0;i<response.Users.length;i++)
        {
            var User = response.Users[i].User;

            if(User.Name &&  User.Name.indexOf(this.store.keyWord)>-1)
            {
                Users.push(response.Users[i]);
            }
        }


        if(Users.length == 0){
            this.store.isLoading = false;
            this.store.isEmpty = true;

        }else {

            this.store.isLoading = false;
            this.store.Users = Users;
            this.store.isEmpty = false;


        }




    }


    //远程搜索好友
    async  _searchUserByLink(){

        //点击搜索用户的时候将之前的数据清空
        this.store.Users =[];

        var Owner =Chat.getLoginInfo().User.IMNr;
        var Param = {

            Keywords:this.store.keyWord,
            Owner:Owner,
            PageSize:100,
        };

        var response = await IM.getSearchUsers(Param);
        if(response.TotalResults == 0){

            this.store.isLoading = false;
            this.store.isEmpty = true;


        }else {

            var SearchedUsers = response.SearchedUsers;


            var CurrentSearchUsers =  SearchedUsers.filter((SearchedUser)=>{
                return SearchedUser.User.IMNr !==Param.Owner;
            })


            this.store.isLoading = false;
            this.store.Users = CurrentSearchUsers;
            this.store.isEmpty = false;

        }


    }


    _ToChatUserInfo(data){


        if(this.store.type == 'INCU'){

            this.props.navigator.push({

                component:ChatUserInfo,
                passProps:{
                    Peer:data.IMNr,

                }
            })

        }
        else if(this.store.type == 'Contact'){

            this.props.navigator.push({

                component:ChatUserInfo,
                passProps:{
                    Peer:data.User.IMNr,
                    User:data.User,
                    isContact:true
                }
            })
        }


        else {
            this.props.navigator.push({

                component:ChatUserInfo,
                passProps:{
                    Peer:data.User.IMNr,
                    User:data.User,
                    isContact:data.IsContact
                }
            })

        }



    }

    _ToFriendApplication(data){

        // console.warn('点击跳到好友申请页面,传递ID过去');
        //跳到好友验证页面。回调回来的时候需要将状态处理回来


        if(data.IsContact == false){

            this.props.navigator.push({

                component:FriendApplication,
                passProps:{
                    User:data.User
                }
            })
        }

    }


    //图片预览界面
    _ToPicturePreview=(data)=>{



    }

    _renderLine(){

        return(
            <View style={{backgroundColor:'rgb(235,235,235)',height:0.5,}}></View>
        )
    }




    _renderRow=(data)=>{

        var iconW = Chat.ContactComponent.iconW;
        var margin = Chat.ContactComponent.margin;
        const type = this.store.type;
        var _this =this;

        //搜索用户
        if(type == 'Search_User')
        {

            var ContentW = Chat.window.width - iconW -margin-100;

            var statuTitle = data.IsContact == false ? '添加': '已添加';
            var statuBorderColor = data.IsContact == false ? 'rgb(244,72,72)' : 'rgb(220,220,220)';
            var statuColor =data.IsContact == false ? 'rgb(244,72,72)' : 'rgb(153,153,153)';

            return(


                <TouchableOpacity onPress={()=>{
                    this._ToChatUserInfo(data);
                }}>

                    <View>
                        <View style={{justifyContent:'space-between',flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>

                            <Image style={{ margin:Chat.ContactComponent.margin,resizeMode:'cover',width:Chat.ContactComponent.iconW,height:Chat.ContactComponent.iconW,borderRadius:Chat.ContactComponent.iconW/2}}
                                   source={{uri:Chat.getFaceUrlPath(data.User.FaceUrlPath)}}>

                            </Image>

                            <View style={{backgroundColor:'white',width:ContentW,}}>

                                <Text style={{color:Colors.colors.Chat_Color51,fontSize:15}}>{data.User.Name}</Text>

                            </View>

                            <TouchableOpacity onPress={()=>{this._ToFriendApplication(data)}}>

                                <View style={{flexDirection:'row', backgroundColor:'white', borderRadius:15,width:70,height:30,marginLeft:10, marginRight:10,borderColor:statuBorderColor, borderWidth:0.75,justifyContent:'center',alignItems:'center'}}>

                                    <Text style={{fontSize:12,color:statuColor}}>{statuTitle}</Text>

                                </View>

                            </TouchableOpacity>

                        </View>

                        {this._renderLine()}

                    </View>



                </TouchableOpacity>


            );



        }
        //搜索本地
        else if(type == 'Contact'){

            var ContentW = Chat.window.width - iconW -margin-100;

            return(


                <TouchableOpacity onPress={()=>{
                    this._ToChatUserInfo(data);

                }}>

                    <View>

                        <View style={{flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>

                            <Image style={{ margin:Chat.ContactComponent.margin,resizeMode:'cover',width:Chat.ContactComponent.iconW,height:Chat.ContactComponent.iconW,borderRadius:Chat.ContactComponent.iconW/2}}
                                   source={{uri:Chat.getFaceUrlPath(data.User.FaceUrlPath)}}>

                            </Image>


                            <View style={{backgroundColor:'white',width:ContentW,margin:10,marginLeft:0, justifyContent:'space-between'}}>

                                <Text style={{color:Colors.colors.Chat_Color51,fontSize:15}}>{data.User.Name}</Text>


                            </View>




                        </View>

                        {this._renderLine()}

                    </View>



                </TouchableOpacity>


            );

        }
        //内部同事
        else if(type == 'INCU'){

            var ContentW = Chat.window.width - iconW -margin-100;

            return(
                <TouchableOpacity onPress={()=>{
                    this._ToChatUserInfo(data);

                }}>

                    <View>

                        <View style={{flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>

                            <Image style={{ margin:Chat.ContactComponent.margin,resizeMode:'cover',width:Chat.ContactComponent.iconW,height:Chat.ContactComponent.iconW,borderRadius:Chat.ContactComponent.iconW/2}}
                                   source={{uri:Chat.getFaceUrlPath(data.IconFile)}}>

                            </Image>


                            <View style={{backgroundColor:'white',width:ContentW,margin:10,marginLeft:0, justifyContent:'space-between'}}>

                                <Text style={{color:Colors.colors.Chat_Color51,fontSize:15}}>{data.AliasName}</Text>

                                <Text style={{color:Colors.colors.Chat_Color102,fontSize:13,marginTop:5}}>{data.DepartmentName+'>'+data.TeamName}</Text>


                            </View>




                        </View>

                        {this._renderLine()}

                    </View>



                </TouchableOpacity>


            );




        }

        //图片素材
        else if(type == 'PictureTemplate'){

            const item = data;
            var margin = 10;
            var ImageW =  (window.width - 40) / 2;
            var ImageH =  ImageW *(276/169);
            var w = parseInt(ImageW);
            var h = parseInt(ImageH);
            var scale = '!/fwfh/'+w+'x'+h;
            var  uri = Chat.getPosterImagePath(item.FilePath)+scale;

            return (
                <TouchableOpacity
                    onPress={()=>{

                        if(this.props.getSearchTemplate){

                            this.props.getSearchTemplate(data);
                        }

                        this.props.navigator.pop();



                    }}
                    style={{margin:5,height: ImageH}}>

                    <Image style={{margin:5, width: ImageW, height: ImageH, borderRadius: 5}} source={{uri:uri}}>

                    </Image>


                </TouchableOpacity>
            )

        }

        //图片素材备份
        else if(type =='PictureTemplateBeiFen'){


            var w = (window.width-20)/2;
            var h =300;
            var scale = '!/fwfh/'+w+'x'+h;
            var  uri = Chat.getPosterImagePath(data.FilePath)+scale;


            return(

                <TouchableOpacity
                    onPress={()=>{

                        if(this.props.getSearchTemplate){

                            this.props.getSearchTemplate(data);

                        }

                        this.props.navigator.pop();

                    }}
                    style={styles.itemStyle}>

                    <Image style={styles.itemImageStyle} source={{uri:uri}}>

                    </Image>

                </TouchableOpacity>
            )



        }

    }

    _renderHeader=()=>{


    }


    _renderNav(){

        return(
            <YQFNavHeaderView ref="_nav" placeholder={this.store.title} type={'search'} onpressLeft={()=>{this.props.navigator.pop()}}
                              onpressRight={this._search.bind(this)}

                //如果打开的话会造成二次搜索
                // onEndEditing={this._search.bind(this)}
            />
        )

    }
    _renderContent(){

        var contentViewStyle={
            flexDirection:'row',
            flexWrap:'wrap'
        }





        if(this.store.isLoading){

            return(
                <YQFEmptyView title={'正在搜索 '+this.store.keyWord+'   请稍候'} icon={'0xe653'} />
            )
        }
        else  if(this.store.isEmpty){

            return(
                <YQFEmptyView title={'搜索不到对应的数据，请修改搜索关键词'} icon={'0xe15c'} />
            )
        }


        return(


            <ListView
                dataSource={this.store.getDataSource}
                contentContainerStyle={ this.store.type == 'PictureTemplate' &&  contentViewStyle}
                renderHeader={this._renderHeader}
                renderRow={this._renderRow}>

            </ListView>


        )

    }

    render(){


        return(

            <View style={{flex:1,backgroundColor:Colors.colors.Chat_Color235}}>

                {this._renderNav()}
                {this._renderContent()}

            </View>

        )
    }

}

const styles = StyleSheet.create({

    itemStyle: {
        // 对齐方式
        alignItems:'center',
        justifyContent:'center',
        // 尺寸
        width:(window.width-20)/2,
        height:300,
        // 左边距
        margin:5,

    },

    itemImageStyle: {
        // 尺寸
        width:(window.width-20)/2,
        height:300,
        // 间距
        // marginBottom:5
    }


})