/**
 * Created by yqf on 2017/10/30.
 */


//好友推荐

import { observer } from 'mobx-react/native';
import {observable, autorun,computed,action} from 'mobx'
import {Component} from 'react';
import React, { PropTypes } from 'react';
import RCTDeviceEventEmitter from 'RCTDeviceEventEmitter'


import {
    TouchableOpacity,
    StyleSheet,
    Image,
    ListView,
    Text,
    View,
    RefreshControl,
    Dimensions

} from 'react-native';


import {IM} from '../../utils/data-access/im';
import {Chat} from '../../utils/chat'
import Colors from '../../Themes/Colors'
import friendRecommend from '../../stores/Contact/FriendRecommend';


import Avatar from '../../components/SessionAvatar';
import NavBar from '../../components/navBar';
// import YQFNavHeaderView from '../../components/navHeaderView';
import YQFNavBar from '../../components/yqfNavBar';

import ChatUserInfo from '../Chat/ChatUserInfo';
import FriendApplication from './FriendApplication';
import FriendSearch from './FriendSearch';

import {Enumerable}  from 'linq';

let window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,

}



@observer

export default class FriendRecommend extends Component{

    constructor(props){
        super(props);

        this.store = new friendRecommend();

    }

    componentDidMount(){


        this.listener = RCTDeviceEventEmitter.addListener('KickOff',()=>{

            this.props.navigator.popToTop();
        });

        this._fetchData();

    }

    componentWillUnmount(){

        this.listener && this.listener.remove();

    }

    async _fetchData(){


        var Param={
            IMNr:Chat.userInfo.User.IMNr,
            Qty:5
        }

        var result = await IM.getRecommandUsers(Param);
        this.store.Users = result.Users;
        this.store.isLoading = false;
    }

    _renderLoading(){

        if(this.store.isLoading){

            <View style={[styles.center]}>

                <Text>正在为你推荐好友，请稍候...</Text>

            </View>

        }
        return null;


    }

    _renderLine(){

        return(
            <View style={{backgroundColor:'rgb(235,235,235)',height:0.5,}}></View>
        )
    }

    //好友搜索

    _ToFriendSearch(){

        this.props.navigator.push({

            component:FriendSearch,
            passProps:{
                type:'Search_User'
            }
        })

    }

    //用户详情
    _ToChatUserInfo(data){

        this.props.navigator.push({

            component:ChatUserInfo,
            passProps:{
                Peer:data.IMNr,
                User:data,
                isContact:false
            }
        })

    }
    //好友验证
    _ToFriendApplication(data){

        //跳到好友验证页面。回调回来的时候需要将状态处理回来
      this.props.navigator.push({

          component:FriendApplication,
          passProps:{
              User:data,
          }
      })


        /*
        this.props.navigator.push({

            component:Chat_Contact_Add_Application,

            passProps:{

                data:Data,

                //添加好友的回调


                callback:(value)=>{

                    //添加好友已经成功,将该项修改为data.IsContact == true
                    if(value){

                        if(value.isApply==true)
                        {


                            console.log('正在申请中，----- 等待审核');

                        }
                        else {

                            console.log('申请失败，不理会')

                        }


                    }



                },
            }




        })
        */


    }

    _renderRow=(data)=>{

        var ContentW = window.width -Chat.ContactComponent.iconW -Chat.ContactComponent.margin-100;
        var statuTitle ='添加';
        var statuBorderColor = 'rgb(244,72,72)' ;
        var statuColor = 'rgb(244,72,72)';

        return(


            <TouchableOpacity onPress={()=>{
                this._ToChatUserInfo(data);
            }}>

                <View>
                    <View style={{justifyContent:'space-between',flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>

                        <Image style={{ margin:Chat.ContactComponent.margin,resizeMode:'cover',width:Chat.ContactComponent.iconW,height:Chat.ContactComponent.iconW,borderRadius:Chat.ContactComponent.iconW/2}}
                               source={{uri:Chat.getFaceUrlPath(data.FaceUrlPath)}}>

                        </Image>

                        <View style={{backgroundColor:'white',width:ContentW,}}>

                            <Text numberOfLines={1} style={{color:Colors.colors.Chat_Color51,fontSize:15}}>{data.Name}</Text>
                        </View>

                        <TouchableOpacity onPress={()=>{this._ToFriendApplication(data)}}>

                            <View style={{flexDirection:'row', backgroundColor:'white', borderRadius:15,width:70,height:30,marginLeft:10, marginRight:10,borderColor:statuBorderColor, borderWidth:0.75,justifyContent:'center',alignItems:'center'}}>

                                <Text style={{fontSize:12,color:statuColor}}>{statuTitle}</Text>

                            </View>

                        </TouchableOpacity>
                    </View>

                    {this._renderLine()}

                </View>



            </TouchableOpacity>


        );


    }



    _renderHeader()
    {
        return(


            <View>

                <TouchableOpacity onPress={()=>{


                    this._ToFriendSearch();


                }} style={{backgroundColor:'rgb(230,230,230)',flex:1,height:40}}>


                    <View style={{flex:1,margin:8,borderRadius:3, backgroundColor:'white', justifyContent:'center',alignItems:'center',flexDirection:'row'}}>

                        <Text style={{fontFamily:'iconfontim',fontSize:13,marginRight:3,color:'rgb(153,153,153)'}}>
                            {String.fromCharCode('0xe171')}</Text>
                        <Text style={[{fontSize:13,marginLeft:3,color:'rgb(153,153,153)'}]}>
                            {'搜索'}</Text>

                    </View>



                </TouchableOpacity>


                <View style={this.props.style}>


                    <View style={[{height:25,backgroundColor:'white',alignItems:'center'},styles.row,styles.flex,]}>

                        <Text style={{fontSize:16,fontFamily:'iconfontim',color:'rgb(204,204,204)',marginLeft:10}}>{String.fromCharCode(this.props.icon)}</Text>
                        <Text style={{fontSize:12,color:'rgb(51,51,51)',marginLeft:5}}>{'推荐用户'}</Text>

                    </View>


                    <View style={{backgroundColor:'rgb(235,235,235)',height:0.5,}}></View>



                </View>

            </View>
        );

    }


    _renderNav(){

        return(
            <YQFNavBar title={'添加好友'}
                       leftIcon={'0xe183'}
                       onLeftClick={()=>{this.props.navigator.pop()}} />

        )
    }

    _renderListView(){

        return(
            <ListView scrollEnabled={true}

                      dataSource={this.store.getDataSource}
                      renderHeader={this._renderHeader.bind(this)}
                      renderRow={this._renderRow}>


            </ListView>
        )
    }


    render()

    {

        return(


            <View style={{backgroundColor:'rgb(235,235,235)',flex:1}}>


                {this._renderNav()}

                {this._renderListView()}

                {this._renderLoading()}

            </View>



        );

    }


}




const styles = StyleSheet.create(
    {

        flex:{
            flex:1,
        },
        row:{
            flexDirection:'row',
        },

        center: {

            justifyContent: 'center',
            alignItems: 'center',

        },


    });


