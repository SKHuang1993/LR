/**
 * Created by yqf on 2017/12/6.
 */

//自定义海报  选择版式

import { observer } from 'mobx-react/native';
import {observable, autorun,computed, extendObservable, action, toJS } from 'mobx'

import {Component} from 'react';
import React, { PropTypes } from 'react';

import {
    View,
    Text,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableWithoutFeedback,
    InteractionManager,
    StatusBar,
    WebView,
    AsyncStorage,
    TouchableOpacity,
    Modal,
    DeviceEventEmitter,
    ActivityIndicator,
    Switch,
    Platform,
    Dimensions,

} from  'react-native';

import YQFNavBar from '../../components/yqfNavBar';
import YQFEmptyView from '../../components/EmptyView';
import EditData from '../../components/editData';

import Icon from '../../components/icon';
import {RestAPI,ServingClient} from '../../utils/yqfws';
import {Chat} from '../../utils/chat';

import Colors from '../../Themes/Colors';
import PosterEdit from './PosterEdit';


const window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,
}


var firstArray=['http://pic.lvmama.com//uploads/pc/place2/2015-10-19/48055ba8-d2a7-45c3-a19d-8df1b28a8e15_300_200.jpg','http://pic.lvmama.com//uploads/pc/place2/2015-11-04/196229e0-f500-4eeb-a3a2-299610eaaa98_300_200.jpg'];
var secondArray=['http://pic.lvmama.com//uploads/pc/place2/2015-10-19/0a713ad4-d3a6-41d0-8936-16c9678e3854_300_200.jpg'];
var thirdArray = ['http://pic.lvmama.com//uploads/pc/place2/2017-06-23/aa7522c8-3a40-4556-b46a-57e2f50a3432_300_200.jpg']

class PosterCustomModel extends  Component{

    @observable templateType = 'picture';//图片

    @observable loading = false;
    @observable isEmpty = false;

    @observable selectIndex = 0;

    @observable selectTemplateDict ={};//模版
    // @observable selectPicture ={};//图片

    //模版
    @observable TemplateArray =[];


    @observable titleArray=[

        {name:'热门',select:true,items:['http://publish-pic-cpu.baidu.com/2c02d779-bb8a-4502-be08-8b34505e9b75.jpeg@q_90,w_228,h_152','http://publish-pic-cpu.baidu.com/96fef4e3-a0ef-42e8-84d8-9d8b9aadbf18.jpeg@q_90,w_228,h_152','http://publish-pic-cpu.baidu.com/96fef4e3-a0ef-42e8-84d8-9d8b9aadbf18.jpeg@q_90,w_228,h_152']},
        {name:'目的地',select:false,items:['http://publish-pic-cpu.baidu.com/96fef4e3-a0ef-42e8-84d8-9d8b9aadbf18.jpeg@q_90,w_228,h_152']},
        {name:'供应商',select:false,items:firstArray},
        {name:'主题标签',select:false,items:['http://publish-pic-cpu.baidu.com/96fef4e3-a0ef-42e8-84d8-9d8b9aadbf18.jpeg@q_90,w_228,h_152']},
        {name:'宣传推广',select:false,items:firstArray},
        {name:'招商合作',select:false,items:secondArray},
        {name:'其他',select:false,items:thirdArray},
    ];

    // @observable TemplateArray =this.titleArray[this.selectIndex].items.slice();

    @observable TemplateArray = [
        require('./Images/poster1s.png'),
        require('./Images/poster2s.png'),
        require('./Images/poster3s.png'),
    ]


    @computed get getDataSource(){

        ds = new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !==r2});
        return ds.cloneWithRows(this.titleArray.slice());
    }


    @computed get getTemplateDataSource(){

        ds = new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !==r2});
        return ds.cloneWithRows(this.TemplateArray.slice());
    }


}




@observer
export  default  class PosterCustom extends  Component{

    constructor(props){
        super(props);

        this.store = new PosterCustomModel();

    }


    _ToPosterEdit = ()=>{

        //跳到编辑海报页面，最重要的页面。
        this.props.navigator.push({
            component:PosterEdit,
            passProps:{
                selectIndex:this.store.selectIndex

            }
        })

    }

    renderImageItem = (data,sectionId,rowId)=>{

        return(

            <TouchableOpacity
                onPress={()=>{

               this.store.selectIndex = rowId

                    }}
                style={styles.itemStyle}>

                <Image style={styles.itemImageStyle} source={this.store.TemplateArray[rowId]}>

                </Image>

            </TouchableOpacity>
        )
    }



    renderTemplateImageContainer = ()=>{


        var Images =[
            require('./Images/poster1.png'),
            require('./Images/poster2.png'),
            require('./Images/poster3.png'),
        ];

        var scale = 301/491;
        var margin = 37 /scale;


        var iconW = window.width-margin*2;
        var iconH = iconW/scale;

        return(

            <View style={{marginTop:20}}>

                <Image style={{marginLeft:margin,marginRight:margin, width:iconW,height:iconH}} source={Images[this.store.selectIndex]}>

                </Image>

            </View>

        )

    }

    
    renderTemplateBottom = () =>{

        return (

            <View style={{flexDirection:'row',marginTop:5}}>
                <ListView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={ {flexDirection:'row'}}
                    removeClippedSubviews={false}
                    initialListSize={10}
                    style={{marginLeft:20,marginRight:20}}
                    renderRow={this.renderImageItem}
                    dataSource={this.store.getTemplateDataSource}>
                </ListView>

            </View>
        )

    }


    render = ()=>{

        return(

            <View style={{flex:1,backgroundColor:'rgb(82,84,106)'}}>

                {this.renderNavBar()}

                {this.renderLoading()}

                {this.renderTemplateImageContainer()}

                {this.renderTemplateBottom()}


            </View>
        )

    }


    renderLoading = ()=>{


        if(this.store.loading){
            return (

                <View style={{position:'absolute',top:64,left:0,right:0,bottom:0,alignItems:'center',justifyContent:'center'}}>

                    <Text>正在加载...</Text>

                </View>

            )
        }

        return null

    }



    //这块用于预览时使用
    renderPersonInfo = () =>{

        // console.log('用户详细资料');
        // console.dir(Chat.loginUserResult);
        var userInfo = Chat.userInfo;


        var iconW = 70;
        var iconH = iconW;

        var iconQRCodeW = 60;
        var iconQRCodeH = iconQRCodeW;



        return(

            <View style={{flexDirection:'row',padding:5,backgroundColor:'white',alignItems:'center'}}>

                <Image source={{uri:Chat.getFaceUrlPath(userInfo.User.FaceUrlPath)}}
                       style={{margin:10, justifyContent:'center',alignItems:'center', width:iconW,height:iconH,borderRadius:iconW/2}}>

                </Image>


                <View style={{margin:5}}>

                    <View style={{flexDirection:'row'}}>
                        <Icon icon={'0xe15c'} size={17} color={'green'}/>
                        <Text style={{color:'rgb(51,51,51)',fontSize:15,marginLeft:10}}>{'黄松凯'}</Text>
                    </View>

                    <View style={{flexDirection:'row',marginTop:5}}>

                        <Icon icon={'0xe6c6'} size={17} color={'green'}/>
                        <Text style={{color:'rgb(51,51,51)',fontSize:15,marginLeft:10}}>{'18620038899'}</Text>
                    </View>

                    <View style={{marginTop:5}}>
                        <Text style={{color:'rgb(102,102,102)',fontSize:9}}>{'本文内容供您参考，详情请咨询一起飞®旅行顾问'}</Text>
                        <Text style={{color:'rgb(102,102,102)',fontSize:9}}>{'本旅行方案由一起飞®国际机票网整理出品'}</Text>

                    </View>

                </View>

                <View style={{marginRight:10}}>

                    <Image source={{uri:'http://t.yqf.cn/qr/gIhUKk?level=M&amp;backcolor=%23fff&amp;forecolor=%23000&amp;blockpixel=8&amp;marginblock=1&amp;logo=1'}}
                           style={{borderWidth:2,borderColor:'#FC405F', margin:10,justifyContent:'center',alignItems:'center', width:iconW,height:iconW}}>

                    </Image>

                    <View style={{alignItems:'center',justifyContent:'center'}}>

                    <Text style={{color:'#FD667F',fontSize:8,maxWidth:iconW+10}}>{'扫码即看每日行程'}</Text>
                    <Text style={{color:'#FD667F',fontSize:8,maxWidth:iconW+10}}>{' 与设计师一对一单聊'}</Text>
                    </View>

                </View>

            </View>


        )


    }

    //导航条
    renderNavBar=()=>{
        return(
            <YQFNavBar  leftIcon={'0xe183'}
                        onLeftClick={()=>{this.props.navigator.pop()}}
                        rightText={'下一步'}
                        onRightClick={()=>{

                           this._ToPosterEdit();

                        }}
                        title={'生成海报'}/>
        )
    }
}


var bottomImageItemScale = 51 / 76;
var bottomImageW =  51/ 375 * window.width * 1.5;



const styles = StyleSheet.create({

    itemStyle: {
        // 对齐方式
        alignItems:'center',
        justifyContent:'center',

    },

    itemImageStyle: {
        // 尺寸
        width: bottomImageW,
        height:bottomImageW/bottomImageItemScale,
        margin:10,

    }


})