/**
 * Created by yqf on 2017/12/12.
 */

//海报编辑

import { observer } from 'mobx-react/native';
import {observable, autorun,computed, extendObservable, action, toJS } from 'mobx'
import {Component} from 'react';
import React, { PropTypes } from 'react';
import Video from 'react-native-video';//视频播放
import Myplayer from '../../components/Myplayer'
import { captureRef } from "react-native-view-shot";


import {
    View,
    Text,
    Image,
    CameraRoll,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableWithoutFeedback,
    InteractionManager,
    StatusBar,
    WebView,
    AsyncStorage,
    TouchableOpacity,
    Modal,
    DeviceEventEmitter,
    ActivityIndicator,
    Switch,
    Platform,
    Dimensions,
    TextInput,
    Alert,
    Slider,
    UIManager


} from  'react-native';
import ImagePicker from 'react-native-image-picker';
import {FLEXBOX} from '../../styles/commonStyle'

import YQFNavBar from '../../components/yqfNavBar';
import YQFEmptyView from '../../components/EmptyView';
import EditData from '../../components/editData';

import Icon from '../../components/icon';
import {RestAPI,ServingClient} from '../../utils/yqfws';
import {Chat} from '../../utils/chat';

import Colors from '../../Themes/Colors';
import PosterPreview from './PosterPreview';
import PosterSuccess from './PosterSuccess';

import PictureTemplate from './PictureTemplate';


photoOptions = {
    quality: 0.70,
    allowsEditing: false,
    noData: false,
    maxWidth: FLEXBOX.width * FLEXBOX.pixel,
    maxHeight: FLEXBOX.height * FLEXBOX.pixel,
    storageOptions: {
        skipBackup: true,
        path: 'images'
    }
}


const window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,
}

const ReactNative = require('react-native');


class PosterEditModel extends  Component{



    //视频相关的
    @observable  videoUrl = null;
    @observable  paused = false;
    @observable  showPause = true;
    @observable  duration = 0.0;//总时长
    @observable  currentTime = 0.0;//当前时长

    @observable sliderValue = 0;//滑块的值，代表一个进度
    @observable file_duration = 0;////歌曲长度
    @observable muted = false;////false表示正常，true代表静音
    @observable showVideoToolBar = true; //是否显示工具条






    @observable tp1CityText = '请输入模版1标题';//模版1城市名
    @observable tp2CityText = '请\n输\n入\n模\n版\n2\n标\n题';//模版2城市名
    @observable tp2PriceText = '请输入价格';//模版2价格名
    @observable tp2DescriptionText = '请\n输\n入\n模\n版\n2\n详\n情';//模版2描述名

    @observable tp3CityText = '请输入标题';//模版3城市名
    @observable tp3PriceText = '请输入价格';//模版3价格名
    @observable tp3DescriptionText = '请输入模版3描述';//模版3描述名





    @observable descriptionText = null;//描述性标题
    @observable title = '城市';//标题
    @observable subTitle = '出国定制游，就找一起飞';//副标题


    @observable templateType = 'picture';//图片
    @observable loading = false;
    @observable isEmpty = false;

    @observable selectIndex = 0;

    @observable selectTemplateDict ={};//模版
    @observable selectPicture =null;//图片
    @observable selectQRCode =null;//二维码图片

    @observable screenUri =null;//截图的uri，这个地址用于传到下一个页面，传值过去
    @observable showPreview = false;//显示预览

    @observable FileTypeID =null ;//1代表图片 2代表视频
    @observable selectItem =null;//素材库选中的item

    @observable QRCode =null;//默认的用户个人品牌二维码



}


@observer
export  default  class PosterEdit extends  Component{

    constructor(props){
        super(props);
        this.store = new PosterEditModel();
        this.store.selectIndex = props.selectIndex;

    }


    launchImageLibrary = (callback) => {
        StatusBar.setBarStyle("default");
        ImagePicker.launchImageLibrary(photoOptions, (response) => {
            StatusBar.setBarStyle("light-content");

            console.log('选择二维码图片的结果');
            console.log(response);

            if (response.data) {

                this.store.selectQRCode = response.uri;

            }
        });
    }


    componentDidMount = ()=>{

        this._fetchData()
    }

    _fetchData = async()=>{

        //1.获取用户资料
        // console.log('用户详细资料')
        // console.dir(Chat.loginUserResult);
        //2。获取二维码

        var param ={
            Url:'http://3g.yiqifei.com/i/'+Chat.loginUserResult.AccountNo,
            CreateQRCode:true
        };

        RestAPI.invoke('Base.CreateRoute',param,(response)=>{

            // console.log('生成 Base.CreateRoute  结果')
            // console.dir(response);
            this.store.QRCode= response.Result.QRCode;


        },(error)=>{


        });

        this.store.isLoading = false;

    }


    _choosePhoto = ()=>{

        this.props.navigator.push({
            component:PictureTemplate,
            passProps:{

                getPicture:(selectItem)=>{


                    // console.log('选择图片，这是回调的数据')
                    // console.dir(selectItem);

                    //本地相册
                    if(selectItem && selectItem.uri){

                        // console.log('这里是要显示本地的图片')
                        // console.dir(selectItem);


                        this.store.FileTypeID =1;//这是显示图片的
                        this.store.selectPicture = selectItem.uri;


                    }else {

                        //素材图片
                        if(selectItem.FileTypeID==1){
                            //图片
                            this.store.FileTypeID =1;//这是显示图片的
                            this.store.selectPicture = Chat.getPosterImagePath(selectItem.FilePath);

                        }else {

                            //素材视频
                            //视频（目前是写死的）（这里需要显示为视频组件---）
                            this.store.FileTypeID =2;//这是显示视频的
                            this.store.selectItem = selectItem;//这是选中的item
                            this.store.selectPicture = selectItem.Video.ImageUrl;
                        }

                    }

                }
            }
        })

    }

    screenPhoto = (sth)=>{


        var _this = this;


        if(Chat.isAndroid()){
            captureRef(this.mainBg, {format: 'png', quality: 1}).then(
                (uri) =>{


                    // console.log('截图的结果')
                    // console.dir(uri);


                    var promise = CameraRoll.saveToCameraRoll(uri);

                    promise.then(function(result) {

                        // console.log('截图后保存到手机相册成功了...')

                        Alert.alert('保存成功');

                        //保存完图片跳转到保存成功页面
                        if(sth == 'ToSuccess'){

                            _this.props.navigator.push({
                                component:PosterSuccess,
                                passProps:{

                                }
                            })


                        }

                    }).catch(function(error) {

                        Alert.alert('保存失败');
                    });


                }

            ).catch(
                (error) => {
                    console.log('截图失败了...')
                }
            );
        }else {
            UIManager.takeSnapshot(this.mainBg, {format: 'png', quality: 1}).then(
                (uri) =>{


                    // console.log('截图的结果')
                    // console.dir(uri);


                    var promise = CameraRoll.saveToCameraRoll(uri);

                    promise.then(function(result) {

                        // console.log('截图后保存到手机相册成功了...')

                        Alert.alert('保存成功');

                        //保存完图片跳转到保存成功页面
                        if(sth == 'ToSuccess'){

                            _this.props.navigator.push({
                                component:PosterSuccess,
                                passProps:{

                                }
                            })


                        }

                    }).catch(function(error) {

                        Alert.alert('保存失败');
                    });


                }

            ).catch(
                (error) => {
                    console.log('截图失败了...')
                }
            );

        }




    };

    //预览海报
    PreviewPoster = ()=>{

        //视频，则跳到视频全屏界面
        if(this.store.FileTypeID==2){

            this.props.navigator.push({
                component: Myplayer,
                passProps: {
                    playUrl: this.store.selectItem.FilePath,
                }
            })
        }
        else {
            this.store.showPreview = true
        }

    }

    //保存海报
    SavePoster = ()=>{

        //保存视频
        if(this.store.FileTypeID==2){

            alert('保存海报视频')

        }

        else {

            this.screenPhoto('ToSuccess');


        }



    }



    loadStart = () => {

        this.store.isLoading = true;

        console.log('视频开始加载');
    }

    onLoad = (e) => {

        // console.log('onLoad');
        // console.dir(e);

        this.store.duration = e.duration;

    }

    onProgress = (data) => {


        if (this.store.isLoading) {
            this.store.isLoading = false;
        }

        let val = parseInt(data.currentTime);
        this.store.currentTime = data.currentTime;
        this.store.sliderValue = val;

        // console.log('val')
        // console.dir(val);


    }

    //设置全屏
    fullScreen = () => {

        this.props.navigator.push({
            component: Myplayer,
            passProps: {
                playUrl: this.store.videoUrl
            }
        })

    }

    getCurrentTimePercentage() {
        if (this.store.currentTime > 0) {
            return parseFloat(this.store.currentTime) / parseFloat(this.store.duration);
        } else {
            return 0;
        }
    }

    formatTime(time) {

        // 71s -> 01:11
        let min = Math.floor(time / 60)
        let second = time - min * 60
        min = min >= 10 ? min : '0' + min
        second = second >= 10 ? second : '0' + second
        return min + ':' + second
    }


    onEnd = () => {

        this.store.showPause = true;

        console.log('视频播放完成');

    }
    videoError = () => {

        console.log('视频播放出错');

    }


    /*------------------------------render相关-------------------------------------------------*/


    renderVideoPlayer = () => {

        if (this.store.selectItem) {

            return (

                <View>
                    <TouchableOpacity onPress={()=>{
                    this.store.showVideoToolBar = !this.store.showVideoToolBar
                }}>

                        <Video
                            ref={(player)=>{this.player = player}}
                            source={{uri:this.store.selectItem.FilePath}} // 视频的URL地址，或者本地地址，都可以.
                            rate={1}                   // 控制暂停/播放，0 代表暂停paused, 1代表播放normal.
                            volume={1.0}                 // 声音的放声音的放大倍数大倍数，0 代表没有声音，就是静音muted, 1 代表正常音量 normal，更大的数字表示放大的倍数
                            muted={this.store.muted}                // .....暂时将音量设置为静音，很吵 true代表静音，默认为false..
                            paused={this.store.paused}               // true代表暂停，默认为false
                            resizeMode="contain"           // 视频的自适应伸缩铺放行为，contain、stretch、cover
                            repeat={false}                // 是否重复播放
                            playInBackground={false}     // 当app转到后台运行的时候，播放是否暂停
                            playWhenInactive={false}     // [iOS] Video continues to play when control or notification center are shown. 仅适用于IOS
                            onLoadStart={this.loadStart} // 当视频开始加载时的回调函数
                            onLoad={(e)=>{this.onLoad(e)}}    // 当视频加载完毕时的回调函数
                            onProgress={(e)=>{this.onProgress(e)}}    //  进度控制，每250ms调用一次，以获取视频播放的进度
                            onEnd={this.onEnd}           // 当视频播放完毕后的回调函数
                            onError={this.videoError}    // 当视频不能加载，或出错后的回调函数
                            style={{width:window.width,height:250}}
                        >


                        </Video>
                    </TouchableOpacity>
                    {this.renderPleyerUI()}

                </View>
            )
        }

        return null

    }
    renderPleyerUI = () => {

        if (this.store.showVideoToolBar)

            return (

                <View
                    style={{justifyContent:'space-between', alignItems:'center',flexDirection:'row', position:'absolute',height:50,width:window.width, backgroundColor:'rgba(0,0,0,0.7)',bottom:0, left:0,right:0}}>

                    <Icon
                        icon={this.store.paused ? '0xe6cd' : '0xe6cf'}
                        color={'white'}
                        style={{marginLeft:10,marginRight:10}}
                        size={20}
                        onPress={()=>{
                   this.store.paused = !this.store.paused;

                }}/>


                    <Slider
                        ref='slider'
                        style={{ marginRight: 10,width:150}}
                        value={this.store.sliderValue}
                        maximumValue={this.store.duration}
                        step={1}
                        minimumTrackTintColor='#FFDB42'
                        onValueChange={(value) => {

                        this.store.currentTime = value;

                                        }
                                    }
                        onSlidingComplete={(value) => {

                                         this.player.seek(value)
                                    }}
                    />


                    <Text style={{color:'white'}}>{this.formatTime(Math.floor(this.store.currentTime))}
                        / {this.formatTime(Math.floor(this.store.duration))}</Text>

                    <Icon
                        icon={this.store.muted ? '0xe6d6' : '0xe6d0'}
                        color={'white'}
                        style={{marginLeft:10,marginRight:10}}
                        size={20}
                        onPress={()=>{
                        this.store.muted = !this.store.muted

                }}/>


                    <Icon
                        icon={'0xe6d2'}
                        color={'white'}
                        size={20}
                        style={{marginLeft:10,marginRight:10}}
                        onPress={()=>{

                        this.store.paused = true

                   this.fullScreen()
                }}/>


                </View>

            )

        return null

    }

    //海报头部
    renderPosterHead = () =>{

        var margin = 20;//不管什么屏幕，都保留这个Margin
        var headImageW = window.width-margin*2;
        var headImageH = headImageW * (66 / 301);


        // var titleRight =



        return(

            <Image
                source={require('./Images/templateHead.png')}
                style={{position:'absolute',top:0, width:headImageW,height:headImageH}}>

                <Text
                    onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.title,
                           getDetail:(text)=>{

                                    var maxLength = text.length>5 ? 5 :text.length;

                                    //还必须去掉换行符


                                    this.store.title = text.substring(0,maxLength);
                           }
                        }
                    })
                }}
                    style={{position:'absolute',width:150,bottom:30, right:20, textAlign:'center', backgroundColor:'transparent', fontSize:25,color:'white',fontWeight:'bold'}}>
                    {this.store.title}
                </Text>


                <Text
                    onPress={()=>{
                    this.props.navigator.push({


                        component:EditData,
                        passProps:{

                           placeholder:this.store.subTitle,
                           getDetail:(text)=>{
                                    var maxLength = text.length>12 ? 12 :text.length;
                                    this.store.subTitle = text.substring(0,maxLength);
                           }
                        }
                    })
                }}
                    style={{position:'absolute',width:150,bottom:7, right:20,fontSize:10, textAlign:'center', backgroundColor:'transparent',color:'rgb(51,51,51)'}}>
                    {this.store.subTitle}
                </Text>


            </Image>
        )

    }


    //素材1
    renderTemplate0 = ()=>{

        var margin=10;

        return(

            <View>


            <Text

                onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp1CityText,
                           getDetail:(text)=>{

                                    var maxLength = text.length>7 ? 7 :text.length;
                                    this.store.tp1CityText = text.substring(0,maxLength);
                           }

                        }
                    })
                }}
                style={{backgroundColor:'transparent', textShadowColor:'rgb(0,0,0)',textShadowOffset:{width:3,height:3},  margin:20,padding:5,fontSize:36,color:'white',fontWeight:'bold'}}>
                {this.store.tp1CityText}
            </Text>



            </View>
        )

    }

    //素材2
    renderTemplate1 = ()=>{

        var margin=20;
        var ContentW = window.width-margin*2;
        var ContentH = ContentW * (407 / 301);

        var right = ContentW *(13/301);
        var top = ContentH * (79 / 404);
        var width = ContentW *(128/301);
        var height = width * (261 / 128);

        var textMargin = width *(11 /  128);


        var PriceMarginLeft =  ContentW *(150/301);
        var PriceMarginTop=  ContentH *(320/404);



        return(

            <View style={{position:'absolute',top:0,left:0,right:0,bottom:0}}>

                <View style={{position:'absolute',top:top,right:right,width:width,height:height, flexDirection:'row-reverse', backgroundColor:'rgba(0,0,0,0.6)'}}>

                    <Text
                        numberOfLines={0}
                        onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp2CityText,
                           getDetail:(text)=>{

                               var maxLength = text.length>10 ? 10 :text.length;

                               var test='';
                               for (var i = 0; i < maxLength; i++) {
                                    test+=text.charAt(i)+'\n'
                               }

                              this.store.tp2CityText = test
                           }

                        }
                    })
                }} style={{color:'white',fontSize:20,padding:textMargin,fontWeight:'bold'}}>{this.store.tp2CityText}</Text>

                    <Text
                        onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp2DescriptionText,
                           getDetail:(text)=>{

                                    var maxLength = text.length>10 ? 10 :text.length;
                               var test='';

                               for (var i = 0; i < maxLength; i++) {
                                    test+=text.charAt(i)+'\n';
                               }

                               this.store.tp2DescriptionText = test

                           }

                        }
                    })
                }}

                        numberOfLines={0}
                        style={{ color:'white',fontSize:14,padding:textMargin}}>{this.store.tp2DescriptionText}</Text>

                </View>


                <View style={{alignItems:'flex-end', flexDirection:'row', position:'absolute',left:PriceMarginLeft,top:PriceMarginTop}}>

                    <Text
                        onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp2PriceText,
                           getDetail:(text)=>{

                               if(!isNaN(text)){
                                    this.store.tp2PriceText = text
                               }
                               else {
                                   alert('必须填入数字')
                               }

                               //这里需要判断是否为数字
                           }

                        }
                    })
                }}
                        style={{fontStyle:'italic', textShadowColor:'#FC405F',textShadowOffset:{width:2,height:2},  backgroundColor:'transparent', padding:10,paddingLeft:0,paddingBottom:5, fontSize:24,color:'white',fontWeight:'bold',}}>{this.store.tp2PriceText}</Text>

                    <View style={{backgroundColor:'transparent'}}>
                        <Text style={{fontSize:9,color:'white',textShadowColor:'#FC405F',textShadowOffset:{width:1,height:1},}}>一人价</Text>
                        <Text style={{fontSize:9,color:'white',textShadowColor:'#FC405F',textShadowOffset:{width:1,height:1},}}>RMB</Text>
                    </View>

                </View>


            </View>



        )




    }



    renderTemplate2 = ()=>{



        var margin=20;
        var ContentW = window.width-margin*2;
        var scaleMargin = ContentW *(13 / 301);


        return(


            <View style={{width:ContentW, flexDirection:'column-reverse', justifyContent:'flex-end'}}>

                <Text
                    onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp3DescriptionText,
                           getDetail:(text)=>{

                               this.store.tp3DescriptionText = text
                           }

                        }
                    })
                }}
                    numberOfLines={0}
                    style={{backgroundColor:'transparent', textShadowColor:'rgb(0,0,0)',textShadowOffset:{width:3,height:3},
                     margin:scaleMargin,fontSize:14,color:'#fff',fontWeight:'bold',}}>{this.store.tp3DescriptionText}</Text>



                <View style={{flexDirection:'row',margin:scaleMargin,marginTop:0,alignItems:'flex-end'}}>

                    <View style={{shadowColor:'red',shadowOffset:{width:3,height:3}, backgroundColor:'rgb(206,67,250)',flexDirection:'row',alignItems:'flex-end'}}>

                        <Text style={{color:'white',fontSize:14,padding:5,fontWeight:'bold'}}>¥</Text>


                        <Text
                            onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp3PriceText,
                           getDetail:(text)=>{

                               if(!isNaN(text)){
                                    this.store.tp3PriceText = text
                               }
                               else {
                                   alert('必须填入数字')
                               }

                               //这里需要判断是否为数字
                           }

                        }
                    })
                }}

                            style={{backgroundColor:'transparent', padding:10,paddingLeft:0,paddingBottom:5, fontSize:20,color:'white',fontWeight:'bold',}}>{this.store.tp3PriceText}</Text>


                    </View>


                    <Text style={{textShadowColor:'rgb(0,0,0)',textShadowOffset:{width:3,height:3}, backgroundColor:'transparent',marginLeft:5, color:'rgb(255,255,255)',fontWeight:'bold',fontSize:16}}>{'一人价'}</Text>

                </View>



                <Text
                    onPress={()=>{
                    this.props.navigator.push({

                        component:EditData,
                        passProps:{

                           placeholder:this.store.tp3CityText,
                           getDetail:(text)=>{

                               var maxLength = text.length>5 ? 5 :text.length;

                               this.store.tp3CityText = text.substring(0,maxLength);

                           }

                        }
                    })
                }}

                    style={{backgroundColor:'transparent',textShadowOffset:{width:2,height:2},  textShadowColor:'white', margin:scaleMargin,padding:5, fontSize:50,color:'rgb(206,67,249)',fontWeight:'bold',}}>{this.store.tp3CityText}</Text>






            </View>

        )



    }

    renderTemplate = ()=>{
        if(this.store.selectIndex == 0){
          return  this.renderTemplate0();
        }
        else  if(this.store.selectIndex == 1){
            return  this.renderTemplate1();
        }

        else  if(this.store.selectIndex == 2){
            return  this.renderTemplate2();
        }
        return null

    }


    renderMainBg = ()=>{


        var margin = 20;//不管什么屏幕，都保留这个Margin
        var ImageW = window.width-margin*2;
        var ImageH = ImageW * (407 / 301);

        var addVideoStyle = null;
        if( this.store.selectIndex==1){

            addVideoStyle={

                position:'absolute',
                left:10,
                top:ImageH/3,
                alignItems:'center',
            }

        }else {
            addVideoStyle={
                alignItems:'center',
                justifyContent:'center'
            }

        }





        return(

            <View ref={(mainBg)=>{this.mainBg = mainBg}} style={{margin:margin,marginTop:0,marginBottom:0, backgroundColor:'rgb(205,205,205)'}}>

                <TouchableOpacity onPress={()=>{this._choosePhoto();}}>

                    {

                        this.store.FileTypeID && this.store.selectPicture?
                            <Image

                                source={{uri:this.store.selectPicture}}
                                style={{ width:ImageW,height:ImageH}}>

                                <View style={{flexDirection:'column-reverse',flex:1}}>

                                    {this.renderTemplate()}

                                    {this.store.FileTypeID == 2?
                                        <Icon onPress={()=>{this.PreviewPoster()}} size={30} style={{position:'absolute',left:ImageW/2-10,top:ImageH/2-10,   backgroundColor:'transparent'}} icon={'0xe6cc'} color={'white'}></Icon>
                                        :
                                        null
                                    }


                                </View>

                            </Image>

                            :

                            <View style={{width:ImageW,height:ImageH,alignItems:'center',justifyContent:'center'}}>

                                <View style={[{ alignItems:'center',justifyContent:'center'}]}>
                                    <Icon icon={'0xe119'} size={40} color={'#B3B3B3'}/>
                                    <Text  style={{color:'#999999',fontSize:15,marginTop:10}}>{'添加视频或者图片'}</Text>
                                </View>

                            </View>

                    }

                </TouchableOpacity>

                {this.renderPosterHead()}
                {this.renderPersonInfo()}
            </View>
        )



    }


    //这里的个人品牌二维码直接获取旧海报的个人二维码
    renderPersonInfo = () =>{

        var userInfo = Chat.userInfo;

        // console.log('renderPersonInfo userInfo');
        // console.dir(userInfo)

        var margin = 20;//不管什么屏幕，都保留这个Margin
        //总宽高
        var contentWidth = window.width-margin*2;//底部资料宽度
        var contentHeight = contentWidth *(84 / 301);


        //左边
        var iconW = contentWidth * (51 / 301);//个人头像宽度
        var iconH = iconW;//个人头像高度
        var iconMargin = contentWidth * (15/301);


        //右边
        var iconQRCodeW = contentWidth *(49 / 301) ;
        var iconQRCodeH = iconQRCodeW;
        var rightMargin = contentWidth * (12 / 301) ;


        var qcodeSize = contentWidth *(19 / 301);


        //中间
        var centerContentLeft =contentWidth * (65 / 301);
        var centerContentTop =iconMargin+5;
        var centerImageW = contentWidth *(10 / 301);
        var centerImageH = centerImageW;
        var centerMargin =  contentWidth *(5 / 301);





        var phone = Chat.loginUserResult.DetailInfo &&  Chat.loginUserResult.DetailInfo.StaffWorkPhone ? Chat.loginUserResult.DetailInfo.StaffWorkPhone : '';
        var text1 ='本文内容供您参考，详情请咨询一起飞®旅行顾问';
        var text2 ='本旅行方案由一起飞®国际机票网整理出品';

        return(

            <View style={{ width:contentWidth,height:contentHeight, flexDirection:'row',backgroundColor:'white'}}>

                <Image source={{uri:Chat.getFaceUrlPath(userInfo.User.FaceUrlPath)}}
                       style={{position:'absolute',left:iconMargin/2,top:iconMargin,justifyContent:'center',alignItems:'center', width:iconW,height:iconH,borderRadius:iconW/2}}>

                </Image>


                <View style={{position:'absolute',top:rightMargin,right:rightMargin/2}}>
                    {
                        this.store.QRCode ?

                            <View

                                style={{}}>

                                <Image source={{uri:this.store.QRCode}}
                                       style={{borderWidth:2,borderColor:'#FC405F',justifyContent:'center',alignItems:'center', width:iconQRCodeW,height:iconQRCodeH}}>


                                    <Image  style={{width:20,height:20}}
                                            source={{uri:Chat.getFaceUrlPath(Chat.userInfo.User.FaceUrlPath)}}>

                                    </Image>


                                </Image>

                                <View style={{alignItems:'center',justifyContent:'center',padding:2}}>

                                    <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'扫码即看每日行程'}</Text>
                                    <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'与设计师一对一单聊'}</Text>

                                </View>

                            </View>
                            :
                           null
                    }





                </View>



                <View style={{ position:'absolute',left:centerContentLeft,top:centerContentTop}}>

                    <View style={{flexDirection:'row',alignItems:'center'}}>

                        <Image source={require('./Images/templateName.png')} style={{width:centerImageW,height:centerImageH}}></Image>
                        <Text style={{color:'rgb(51,51,51)',fontSize:10,marginLeft:centerMargin,fontWeight:'bold'}}>{Chat.userInfo.User.Name}</Text>
                    </View>

                    <View style={{flexDirection:'row',alignItems:'center',marginTop:centerMargin}}>

                        <Image source={require('./Images/templatePhone.png')} style={{width:centerImageW,height:centerImageH}}></Image>
                        <Text style={{color:'rgb(51,51,51)',fontSize:10,marginLeft:centerMargin,fontWeight:'bold'}}>{phone}</Text>
                    </View>


                    <View style={{marginTop:centerMargin}}>
                        <Text style={{color:'rgb(102,102,102)',fontSize:8}}>{text1}</Text>
                        <Text style={{color:'rgb(102,102,102)',fontSize:8}}>{text2}</Text>

                    </View>

                </View>


            </View>


        )



    }

    //这块用于预览时使用
    renderPersonInfoOld = () =>{

        var userInfo = Chat.userInfo;

        // console.log('renderPersonInfo userInfo');
        // console.dir(userInfo)

        var margin = 20;//不管什么屏幕，都保留这个Margin
        //总宽高
        var contentWidth = window.width-margin*2;//底部资料宽度
        var contentHeight = contentWidth *(84 / 301);


        //左边
        var iconW = contentWidth * (51 / 301);//个人头像宽度
        var iconH = iconW;//个人头像高度
        var iconMargin = contentWidth * (15/301);


        //右边
        var iconQRCodeW = contentWidth *(49 / 301) ;
        var iconQRCodeH = iconQRCodeW;
        var rightMargin = contentWidth * (12 / 301) ;



        var qcodeSize = contentWidth *(19 / 301);


        //中间
        var centerContentLeft =contentWidth * (65 / 301);
        var centerContentTop =iconMargin+5;
        var centerImageW = contentWidth *(10 / 301);
        var centerImageH = centerImageW;
        var centerMargin =  contentWidth *(5 / 301);





        var phone = Chat.loginUserResult.DetailInfo &&  Chat.loginUserResult.DetailInfo.StaffWorkPhone ? Chat.loginUserResult.DetailInfo.StaffWorkPhone : '';
        var text1 ='本文内容供您参考，详情请咨询一起飞®旅行顾问';
        var text2 ='本旅行方案由一起飞®国际机票网整理出品';

        return(

            <View style={{ width:contentWidth,height:contentHeight, flexDirection:'row',backgroundColor:'white'}}>

                <Image source={{uri:Chat.getFaceUrlPath(userInfo.User.FaceUrlPath)}}
                       style={{position:'absolute',left:iconMargin/2,top:iconMargin,justifyContent:'center',alignItems:'center', width:iconW,height:iconH,borderRadius:iconW/2}}>

                </Image>


                <View style={{position:'absolute',top:rightMargin,right:rightMargin/2}}>
                    {
                        this.store.selectQRCode ?

                            <TouchableOpacity
                                onPress={()=>{this.launchImageLibrary();}}
                                style={{}}>

                                <Image source={{uri:this.store.selectQRCode}}
                                       style={{borderWidth:2,borderColor:'#FC405F',justifyContent:'center',alignItems:'center', width:iconQRCodeW,height:iconQRCodeH}}>

                                </Image>

                                <View style={{alignItems:'center',justifyContent:'center',padding:2}}>

                                    <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'扫码即看每日行程'}</Text>
                                    <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'与设计师一对一单聊'}</Text>

                                </View>

                            </TouchableOpacity>
                            :
                            <TouchableOpacity
                                onPress={()=>{this.launchImageLibrary();}}
                                style={{}}>

                                <View
                                    style={{backgroundColor:'rgb(205,205,205)',justifyContent:'center',alignItems:'center', width:iconQRCodeW,height:iconQRCodeH}}>

                                    <View style={{alignItems:'center',justifyContent:'center'}}>

                                        <Icon icon={'0xe119'} size={qcodeSize} color={'#B3B3B3'}/>

                                        <Text style={{color:'#999999',fontSize:10,marginTop:0}}>{'二维码'}</Text>

                                    </View>


                                </View>

                                <View style={{alignItems:'center',justifyContent:'center'}}>

                                    <Text style={{color:'#FD667F',fontSize:7}}>{'扫码即看每日行程'}</Text>
                                    <Text style={{color:'#FD667F',fontSize:7}}>{'与设计师一对一单聊'}</Text>
                                </View>

                            </TouchableOpacity>
                    }





                </View>



                <View style={{ position:'absolute',left:centerContentLeft,top:centerContentTop}}>

                    <View style={{flexDirection:'row',alignItems:'center'}}>

                        <Image source={require('./Images/templateName.png')} style={{width:centerImageW,height:centerImageH}}></Image>
                        <Text style={{color:'rgb(51,51,51)',fontSize:10,marginLeft:centerMargin,fontWeight:'bold'}}>{Chat.userInfo.User.Name}</Text>
                    </View>

                    <View style={{flexDirection:'row',alignItems:'center',marginTop:centerMargin}}>

                        <Image source={require('./Images/templatePhone.png')} style={{width:centerImageW,height:centerImageH}}></Image>
                        <Text style={{color:'rgb(51,51,51)',fontSize:10,marginLeft:centerMargin,fontWeight:'bold'}}>{phone}</Text>
                    </View>


                    <View style={{marginTop:centerMargin}}>
                        <Text style={{color:'rgb(102,102,102)',fontSize:8}}>{text1}</Text>
                        <Text style={{color:'rgb(102,102,102)',fontSize:8}}>{text2}</Text>

                    </View>

                </View>


            </View>


        )



    }


    renderMainBg1 = ()=>{


        var oldMargin = 37;//不管什么屏幕，都保留这个Margin


        var oldScale = 37 / 375;
        var margin=window.width * oldScale;

        var scale = 300 / 407;//模版图片的比例
        var contentWidth = window.width-oldMargin*2;


        var contentHeight = contentWidth / scale;

        var padding=10;


        return(
            <View ref={(mainBg)=>{this.mainBg = mainBg}} style={{margin:oldMargin,backgroundColor:'rgb(205,205,205)'}}>



                <TouchableOpacity onPress={()=>{this._choosePhoto();}}>

                    {

                        this.store.FileTypeID?

                            <Image

                                source={{uri:this.store.selectPicture}}
                                style={{ width:contentWidth,height:contentHeight}}>

                                <View style={{flexDirection:'column-reverse',flex:1}}>

                                    {this.renderTemplate()}

                                    {this.store.FileTypeID == 2?
                                        <Icon onPress={()=>{this.PreviewPoster()}} size={30} style={{position:'absolute',left:contentWidth/2-10,top:contentHeight/2-10,   backgroundColor:'transparent'}} icon={'0xe6cc'} color={'white'}></Icon>
                                        :
                                        null

                                    }


                                </View>

                            </Image>

                            :


                            <View style={{alignItems:'center',justifyContent:'center', width:contentWidth,height:contentHeight}}>

                                <Icon icon={'0xe119'} size={40} color={'#B3B3B3'}/>

                                <Text  style={{color:'#999999',fontSize:15,marginTop:10}}>{'添加视频或者图片'}</Text>


                            </View>
                    }

                </TouchableOpacity>

                {this.renderPosterHead()}

                {this.renderPersonInfo()}

            </View>
        )

    }

    renderContent = ()=>{


        //图片宽度


        return(


            <ScrollView ref={(scrollview)=>{this.scrollview = scrollview}}>




            <View style={{flexDirection:'row',alignItems:'center',justifyContent:'center'}}>
                <Text onPress={()=>{
                    this.PreviewPoster();
                }} style={{padding:10,marginRight:20,color:'#fff',fontSize:22}}>预览</Text>
                <Text onPress={()=>{
                    this.SavePoster();
                }} style={{padding:10,marginLeft:20,color:'#fff',fontSize:22}}>保存</Text>
            </View>

                {this.renderMainBg()}


            </ScrollView>

        )



    }



    render = ()=>{


        //显示预览界面
        if(this.store.showPreview){

            return(

                <View style={{flex:1,backgroundColor:'rgb(0,0,0)'}}>

                    <View style={{height:40,flexDirection:'row',alignItems:'center',justifyContent:'space-between',margin:20}}>

                        <Icon onPress={()=>{this.store.showPreview=false}} icon={'0xe183'} size={20} color={'white'}/>
                        <Text onPress={()=>{

                            this.store.showPreview=false;
                            this.screenPhoto('ToSuccess')
                        }} style={{fontSize:20,color:'white'}}>{'保存'}</Text>

                    </View>




                        <View accessible={false}
                              pointerEvents='none'

                        >

                    {this.renderMainBg()}
                        </View>



                </View>
            )

        }


        else  return(

            <View style={{flex:1,backgroundColor:'rgb(72,74,74)'}}>


                {this.renderNavBar()}
                {this.renderContent()}


            </View>
        )

    }


    renderQRCode = () =>{


        var margin=10;
        var contentWidth = window.width-margin*2;
        var iconQRCodeW = 60;
        var iconQRCodeH = iconQRCodeW;

        if(this.store.selectQRCode){

            return(

                <TouchableOpacity
                    onPress={()=>{this.launchImageLibrary();}}
                    style={{marginRight:10}}>

                    <Image source={{uri:this.store.selectQRCode}}
                           style={{borderWidth:3,borderColor:'#FC405F', margin:10,justifyContent:'center',alignItems:'center', width:iconQRCodeW,height:iconQRCodeH}}>

                    </Image>

                    <View style={{alignItems:'center',justifyContent:'center'}}>

                        <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'扫码即看每日行程'}</Text>
                        <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'与设计师一对一单聊'}</Text>
                    </View>

                </TouchableOpacity>

            )


        }
        else {

            return(

                <TouchableOpacity
                    onPress={()=>{this.launchImageLibrary();}}
                    style={{marginRight:10}}>

                    <View
                           style={{backgroundColor:'rgb(205,205,205)', margin:10,justifyContent:'center',alignItems:'center', width:iconQRCodeW,height:iconQRCodeH}}>

                        <View style={{alignItems:'center',justifyContent:'center', width:contentWidth}}>

                            <Icon icon={'0xe119'} size={25} color={'#B3B3B3'}/>

                            <Text style={{color:'#999999',fontSize:13,marginTop:5}}>{'二维码'}</Text>

                        </View>


                    </View>

                    <View style={{alignItems:'center',justifyContent:'center'}}>

                        <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'扫码即看每日行程'}</Text>
                        <Text style={{color:'#FD667F',fontSize:7,maxWidth:iconQRCodeW+10}}>{'与设计师一对一单聊'}</Text>
                    </View>

                </TouchableOpacity>

            )

        }

    }




    //导航条
    renderNavBar=()=>{
        return(
            <YQFNavBar  leftIcon={'0xe183'}
                        onLeftClick={()=>{this.props.navigator.pop()}}
                        title={'编辑海报'}/>
        )
    }



}


const styles = StyleSheet.create({

    itemStyle: {
        // 对齐方式
        alignItems:'center',
        justifyContent:'center',

    },

    itemImageStyle: {
        // 尺寸
        width:  60,
        height:100,
        margin:10,
        margin:5,


    }


})