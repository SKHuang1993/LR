

import { observer } from 'mobx-react/native';
import {observable, autorun,computed, extendObservable, action, toJS } from 'mobx'
import {Component} from 'react';
import React, { PropTypes } from 'react';


import {
    View,
    Text,
    Image,
    StyleSheet,
    ListView,
    ScrollView,
    TouchableWithoutFeedback,
    InteractionManager,
    StatusBar,
    WebView,
    AsyncStorage,
    TouchableOpacity,
    Modal,
    DeviceEventEmitter,
    Switch,
    Platform,
    Dimensions,
    RefreshControl,
    ActivityIndicator

} from  'react-native';


import YQFNavBar from '../../components/yqfNavBar';
import PosterList from './PosterList'
import PosterRecord from './PosterRecord';
import PosterCustom from './PosterCustom';

const window={

    width:Dimensions.get('window').width,
    height:Dimensions.get('window').height,

}




class  PosterEntranceModel extends  Component{

    @observable SortByCreate = false;//按上传时间排序

    @observable PageSize = 10;//数目
    @observable PageCount = 1;//页码
    @observable isVideoRefreshing = false;//是否刷新
    @observable RowCount = 0;
    @observable isLoading =true;//是否显示loading

    @observable selectIndex = 1;

    @observable Posters = [];

    @observable titleArray=[
        {name:'自选海报',select:false},
        {name:'早中晚报',select:true},

    ];

    @computed get getTitleDataSource(){

        ds1 = new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !==r2});
        return ds1.cloneWithRows(this.titleArray.slice());
    }

    @computed get getDataSource(){

        ds2 = new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !==r2});
        return ds2.cloneWithRows(this.Posters.slice());

    }

}

@observer
export  default class  PosterEntrance extends  Component{

    constructor(props){
        super(props);
        this.store = new PosterEntranceModel();
    }


    componentDidMount = ()=>{

    }


    _ToPosterRecord = ()=>{

        this.props.navigator.push({
            component:PosterRecord,

        })

    }






    _renderNav1(){
        return(
            <YQFNavBar title={'海报'}
                       leftIcon={'0xe183'}


                       onLeftClick={()=>{this.props.navigator.pop()}} />
        )
    }


    _renderNav(){
        return(
            <YQFNavBar title={'海报'}
                       leftIcon={'0xe183'}
                       rightText={'我的生成记录'}
                       onRightClick={()=>{this._ToPosterRecord()}}
                       onLeftClick={()=>{this.props.navigator.pop()}} />
        )
    }




    render() {

        return(

            <View style={{backgroundColor:'rgb(235,235,235)',flex:1}}>

                {this._renderNav()}


                <View style={{margin:30, flexDirection:'row',justifyContent:'space-around', alignItems:'center'}}>


                    <TouchableOpacity onPress={()=>{
                        this.props.navigator.push({component:PosterList})
                    }} style={{margin:0,backgroundColor:'rgb(255,255,255)'}}>

                        <Text style={{padding:30,color:'rgb(102,102,102)',fontSize:16}} >{'早中晚报'}</Text>

                    </TouchableOpacity>

                    <TouchableOpacity onPress={()=>{

                      this.props.navigator.push({component:PosterCustom})


                }} style={{margin:0,backgroundColor:'rgb(255,255,255)'}}>

                        <Text style={{padding:30,color:'rgb(102,102,102)',fontSize:16}} >{'自选海报'}</Text>

                    </TouchableOpacity>



                </View>






          </View>



        );

    }



}







